#include <stdio.h>

void test2(void)
{
    printf("\nHello from test2!");
}
